<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>Untitled Document</title>

    <style type="text/css">
        body {
            font: 100%/1.4 Verdana, Arial, Helvetica, sans-serif;
            padding: 0;
            color: #000;
            
        }
        
       
        .container {
            width: 960px;
            background:cornsilk;
            margin: 0 auto;
            /* the auto value on the sides, coupled with the width, centers the layout */
            margin-top: 20vh;
        }
        /* ~~ the header is not given a width. It will extend the full width of your layout. It contains an image placeholder that should be replaced with your own linked logo ~~ */
        
        .header {
            background:orange;
            letter-spacing: 0.5em;
            font-size: 60px;
            padding-left: 50px;
            height: 100px;
            position: relative;
            text-align: center;
            color:white;
            font-weight: 900;
        }
        
        .content {
            padding: 20px 0;
            text-align: center;
        }
        /* ~~ The footer ~~ */
        
        .footer {
            padding: 10px;
            background:  orange;
            font-style: italic;
        }
        
        .container .footer p {
            font-style: italic;
            text-align: right;
            font-size: 14px;
            color:white;
        }
        input{
            text-align: center;
        }
        p {
            font-size: 14%;
        }
        
        p {
            font-size: 14px;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header"> MYGYM

        </div>

        <div class="content">
           
            <?php
                //print_r($_REQUEST);

                function test_input($data){
                    $data = trim($data);
                    $data = stripslashes($data);
                    $data = htmlspecialchars($data);
                    return $data;
                }
                if (!isset($_POST['clave']) || !isset($_POST['reserva'])){
                    echo "<p>No has marcado ninguna opción</p><br>";
                    echo "<a href='index.html'>Volver página inicial</a>";
                
                }else{
                    
                    $reserva = test_input($_POST['reserva']);
                    $clave = test_input($_REQUEST['clave']);

                    switch ($reserva){
                        case 1:
                            ?>
                                <form action="anular.php" method="POST">
                                    <p>Anota el número de la reserva que quieres anular:
                                        <input type="text" name="numero">
                                    </p><input type="submit" value="ANULAR">
                                </form>
                            <?php
                        break;
                        case 2:
                            $servername = "localhost";
                            $username = "otro";
                            $password = "";
                            $dbname = "gym";
            
            
                            // Create connection
                            $conn = mysqli_connect($servername, $username, $password, $dbname);
                            // Check connection
                            if (!$conn) {
                                die("Connection failed: " . mysqli_connect_error());
                            }
                            
                            try {
                                $sql = "SELECT * FROM clases WHERE plazas >= ocupadas";
                                $result = mysqli_query($conn, $sql);
                                // Comprobamos el número de filas que devuelve la select
            
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<p>".$row['disciplina'].' '.$row['plazas'].' '.$row['ocupadas'].' '.$row['codigo']."</p>";
                                    }

                                    ?>
                                        <form action="reservar.php" method="POST">
                                            <p>Anota el codigo de la clase:
                                                <input type="text" name="codclase"><br>
                                                <input type="hidden" name="clave" value=<?php echo $clave?> >
                                            </p><input type="submit" value="SEGUIR">
                                        </form>
                                    <?php
                                
                                } else {
                                    echo "<p>No hay reservas disponibles</p>";
                                    echo "<a href='index.html'>Volver página inical</a>";
                                }
                                
            
                                mysqli_close($conn);
                            } catch (Exception $e) {
                                echo "Se ha producido un error al buscar las plazas";
                                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                            }

                        break;
                    }

                }

            ?>
            
        </div>
        <div class="footer ">
            <p>Copyright SalesianasNSPilar</p>
            <!-- end .footer -->
        </div>
        <!-- end .container -->
    </div>
</body>

</html>