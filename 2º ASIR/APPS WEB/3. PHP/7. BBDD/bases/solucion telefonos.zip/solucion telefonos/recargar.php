<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Untitled Document</title>

	<style type="text/css">

/*Da a un botón la apariencia de link*/
.link-button { 
     background: none;
     border: none;
     color: #1a0dab;
     text-decoration: underline;
     cursor: pointer; 
	 
}
		body {
			font: 100%/1.4 Verdana, Arial, Helvetica, sans-serif;
			background: #42413C;
			padding: 0;
			color: #000;
			font-family: pueblo;
		}


		@font-face {
			font-family: pueblo;
			src: url(caligrafia.ttf);
		}

		/* ~~ Element/tag selectors ~~ */


		/* ~~ this fixed width container surrounds the other divs ~~ */
		.container {
			margin-top: 20vh;
			width: 960px;
			background: #FFF;
			margin: 0 auto;
			/* the auto value on the sides, coupled with the width, centers the layout */
		}

		/* ~~ the header is not given a width. It will extend the full width of your layout. It contains an image placeholder that should be replaced with your own linked logo ~~ */
		.header {
			background: #ADB96E;
			text-align: center;
			font-size: 60px;
			padding-left: 50px;
			height: 100px;
			position: relative;
		}


		.content {
			padding: 10px 0;
			text-align: center;
		}

		/* ~~ The footer ~~ */
		.footer {
			padding: 10px;
			background: #CCC49F;
			font-style: italic;
		}


		.container .footer p {
			font-style: italic;
			text-align: right;
			font-size: 14px;
		}

		p {
			font-size: 14%;
		}

		p {
			font-size: 14px;
		}
	</style>
</head>

<?php
// Función que limpia los datos recibidos
function test_input($data)
{
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
?>

<body>

	<div class="container">
		<div class="header"> Movil Telephone

		</div>

		<div class="content">
			<h1>Area clientes</h1>


			<?php
			if (!isset($_POST['numero']) || !isset($_POST['clave']) || !isset($_POST['importe'])) {
				die("No has llegado aquí a través del formulario");
			} else {

				$numero = test_input($_POST['numero']);
				$clave = test_input($_POST['clave']);
				$importe = test_input($_POST['importe']);

				if ($numero == "" || $clave == "" || $importe == "") {
					echo "<p>No has anotado todos los datos</p>";
					echo "<p><a href='index.html'>Volver a introducir los datos</a></p>";
				} else if (substr($numero, 0, 2) != "66" && substr($numero, 0, 2) != "65") {
					echo "<p>Teléfono incorrecto</p>";
					echo "<a href='index.html'>Volver a introducir los datos</a>";
				} else if ($importe < 10) {
					echo "<p>El importe no puede ser inferior a 10 euros</p>";
					echo "<a href='index.html'>Volver a introducir los datos</a>";
				} else {
					// Accedo a la base de datos 
					$servername = "localhost";
					$username = "nuevo";
					$password = "a1234567";
					$dbname = "telefonos";

					// Create connection
					$conn = mysqli_connect($servername, $username, $password, $dbname);
					// Check connection
					if (!$conn) {
						die("Connection failed: " . mysqli_connect_error());
					}

					try {
						$sql = "SELECT * FROM abonados WHERE numero=$numero and clave='$clave'";
						//echo $sql;
						$result = mysqli_query($conn, $sql);

						// Comprobamos el número de líneas que ha devuelto la instrucción select
						if (mysqli_num_rows($result) > 0) {
							// Extraemos la información de la fila
							$row = mysqli_fetch_assoc($result);
							$nombre=$row['nombre'];
							$apellido=$row['apellido'];
							echo "Bienvenido $nombre $apellido";
							echo "<p>Su saldo anterior:" . $row['saldo'];
							$nuevosaldo = $row['saldo'] + $importe;
							$sql = "update abonados set saldo=$nuevosaldo where numero='$numero'";
							if (mysqli_query($conn, $sql)) {
								// Comprobamos cuantas filas se han modificado
								$filas = mysqli_affected_rows($conn);
								if ($filas > 0) {
									echo "<p>Nuevo saldo:" . $nuevosaldo;
									//$proxima_recarga = getdate(time() + 3600 * 24 * 90); // Sumanos noventa días
									//echo "<p>Debe volver a recargar antes de " . $proxima_recarga['mday'] . "/" . $proxima_recarga['mon'] . "/" . $proxima_recarga['year'] . "</p>";
									$proxima_recarga = strtotime("+90 days");
									echo "<p>".date('d/m/y', $proxima_recarga)."</p>";
									
									//Pasamos los datos en la url
									echo "<a href='mostrar.php?numero=$numero&nombre=$nombre&apellido=$apellido'>Si quiere ver sus llamadas pinche aquí'</a>";
									
								
									?>
									
									<!--
									Pasamos los datos a través de un formulario con campos hidden
									<form method="POST" action="mostrar.php">
									<input type="hidden" name="numero" value=<?php echo $numero?>>
									<input type="hidden" name="nombre" value=<?php echo $nombre?>>
									<input type="hidden" name="apellido" value=<?php echo $apellido?>>
									<input type="submit" class=link-button value="Si quiere ver sus llamadas pinche aqui">
									</form>
									-->
									<?php
								} else {
									echo "<p>Error actualizando tabla abonadaos</p>";
									echo "<p><a href='index.html'>Volver a introducir los datos</a></p>";
								}
							}
						}
						// Si la select no ha devuelto ninguna línea
						else {
							echo "<p>Error de acceso</p>";
							echo "<p><a href='index.html'>Volver a introducir los datos</a></p>";
						}
					} catch (Exception $e) {
						echo "Se ha producido un error accediendo a la base de datos";
						echo "Error: " . $sql . "<br>" . mysqli_error($conn);
					}

					mysqli_close($conn);
				}
			}

			?>
		</div>
		<div class="footer">
			<p>Copyright SalesianasNSPilar</p>
			<!-- end .footer -->
		</div>
		<!-- end .container -->
	</div>
</body>

</html>